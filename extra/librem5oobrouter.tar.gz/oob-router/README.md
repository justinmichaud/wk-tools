# Librem 5 out-of-band router

This phone is a headless Tailscale subnet router that puts **moose's BMC** on
the tailnet, so the machine can be reached when it is powered off, hung, or
its OS is broken.

```
house WiFi ──wlan0── [ Librem 5 "librem5-oob" ] ──bmc0── moose's dedicated BMC port
                              │
                     tailscaled (tag:oob)
                     advertises 10.99.0.0/24
```

| | |
|---|---|
| OS | PureOS 11 (Crimson), Debian 12 bookworm base, kernel 6.12 librem5 |
| Tailnet name | `librem5-oob`, tag `tag:oob`, no key expiry |
| Phone on BMC segment | `10.99.0.1/24` (`bmc0`) |
| BMC | `10.99.0.2/24`, MAC `9c:6b:00:75:5a:d7`, hostname `altrad8ud2-1l2q` |
| Login | `root` and `purism`, **SSH keys only** — password auth is disabled |

**Everything here is the canonical copy.** `moose` was wiped; do not assume a
copy exists anywhere else. Consider pushing this directory to git.

---

## Layout

```
/home/purism/oob-router/          <- you are here (root-owned, not user-writable)
├── README.md                     <- this file
├── bin/                          <- live scripts; /usr/local/sbin symlinks here
│   ├── oob-netwatch              <- network watchdog, runs every 60s
│   ├── oob-usb-host              <- forces the USB-C port into host mode
│   └── provision-oob-router      <- re-applies the ENTIRE configuration
├── etc/                          <- reference copies of everything under /etc
└── tailnet/                      <- tailnet policy + the script that applies it
```

`bin/` is root-owned deliberately. These run as root, so a user-writable
location would be a privilege-escalation hole.

---

## Health check

```sh
sudo oob-healthcheck        # symlinked into /usr/local/sbin
```

It checks the uplink, the BMC segment, the tailnet, every service, the
hardening, and overall systemd state — and exits non-zero if anything is wrong,
so it is safe to run from cron or a monitoring hook.

A caution if you edit it: do **not** write `cmd | grep -q ...` in these scripts.
`grep -q` exits at the first match, which SIGPIPEs the producer, and under
`set -o pipefail` that turns a successful check into a reported failure. This
bug briefly made the health check claim SSH password auth was enabled when it
was not. Capture the value and compare it instead.

Or by hand:

```sh
ip -br addr show bmc0                 # expect 10.99.0.1/24
cat /var/lib/misc/dnsmasq.leases      # expect 9c:6b:00:75:5a:d7 -> 10.99.0.2
ping -c2 10.99.0.2                    # the BMC
tailscale status --json --peers=false | jq '{Tags:.Self.Tags,Routes:.Self.PrimaryRoutes}'
nft list table inet oob
systemctl is-system-running           # expect "running", not "degraded"
```

---

## When it breaks

### Cannot reach the BMC from the tailnet

Work outward from the phone:

1. `ip -br addr show bmc0` — missing? See *bmc0 has vanished* below.
2. `ping -c2 10.99.0.2` from the phone. Fails? The BMC has no lease:
   `journalctl -u dnsmasq | tail`. `no address available` means a stale lease
   holds the single address — see *Wrong device took the BMC address*.
3. `tailscale status --json --peers=false | jq .Self.PrimaryRoutes` — must be
   `["10.99.0.0/24"]`. `null` means the route is not approved; it should
   auto-approve via `autoApprovers` in the tailnet policy.
4. Check the tailnet ACL. **Only humans and `tag:workstation` may reach
   `10.99.0.0/24`.** `tag:app` and `tag:wk` are deliberately excluded, so a
   server or an RPi failing to reach the BMC is correct behaviour.

### bmc0 has vanished

Almost always USB-C data role. The phone has one port and defaults to *device*
mode; it must be *host* for the Ethernet adapter to enumerate.

```sh
cat /sys/class/typec/port0/data_role     # want "[host] device"
sudo /home/purism/oob-router/bin/oob-usb-host
```

`oob-netwatch` also re-runs this automatically whenever `bmc0` is missing.
If the role will not change, the dock is refusing a Data Role Swap — that is a
hardware limitation, not config. Powering the hub *before* connecting it to the
phone changes the negotiation and is worth trying.

### Wrong device took the BMC address

The DHCP pool is exactly one address and the lease is infinite, so whatever
asks first keeps it forever. There is a MAC reservation for the BMC, but a
stale lease from something else still blocks it.

```sh
sudo systemctl stop dnsmasq
sudo rm /var/lib/misc/dnsmasq.leases
sudo systemctl start dnsmasq
```

This happened once for real: the Ethernet cable was plugged into moose's host
NIC instead of the BMC port, moose took `10.99.0.2` permanently, and the BMC
was refused with `no address available`.

### WiFi keeps dropping

Expected to some degree — the RS9116/`rsi` WiFi is the least reliable part of
this device, and the house has two APs on one SSID so the phone roams.

`oob-netwatch` escalates once per failed 60s check, resetting on any success:

| Consecutive failures | Action |
|---|---|
| 1 | log only |
| 2–3 | bounce the WiFi interface |
| 4–5 | restart NetworkManager |
| 6–7 | reload the WiFi driver module |
| 8–9 | restart tailscaled |
| 10+ | reboot (only if uptime > 15 min, max 3 reboots per 6 h) |

```sh
journalctl -t oob-netwatch --since -1h
```

An SSH session dying while the phone stays up is usually a roam, not a fault.
Use keepalives (`ServerAliveInterval 15`) rather than chasing it.

### Locked out

SSH is **key-only**; password auth is off. In order of preference:

1. `tailscale ssh root@librem5-oob` — independent of LAN addressing.
2. `ssh root@<lan-ip>` with an authorised key.
3. The phone's own screen and touchscreen. The GUI is deliberately still
   enabled (`HEADLESS=no`) precisely as this fallback. The `purism` account
   keeps its default password for console login — that is intentional and
   harmless because password auth cannot be used over the network.

To add a key without any of the above, take the microSD/eMMC to another
machine, or re-flash and re-provision.

### System reports "degraded"

```sh
systemctl list-units --state=failed
```

Two units are masked on purpose, and both should stay masked:

* `zramswap.service` — PureOS provides zram via `systemd-zram-generator`, so
  `zram-tools` can never claim `/dev/zram0` and fails permanently.
* `console-setup.service` — fails on every PureOS boot with
  `setupcon: cannot open /tmp/tmpkbd.XXXX`. It only sets the console font and
  keymap. Left failing, it makes `systemctl is-system-running` report
  `degraded` forever, which would hide a real fault.

`session-cN.scope` failures are transient — a dropped SSH session leaves one
behind. `systemctl reset-failed` clears them.

---

## Re-applying the configuration

`provision-oob-router` is **idempotent** — safe to re-run at any time. It is
the single source of truth; prefer editing it over hand-editing `/etc`.

```sh
sudo HEADLESS=no /home/purism/oob-router/bin/provision-oob-router
```

* `HEADLESS=no` keeps the on-screen GUI as a recovery path. `HEADLESS=yes`
  masks phosh and switches to `multi-user.target`.
* `BMC_HW=<mac>` sets the BMC's DHCP reservation (already defaulted).
* Firewall changes do **not** take effect until `nft -f /etc/nftables.d/oob.nft`
  or a reboot.

### Applying a default-deny firewall remotely

Always arm a revert first, or a mistake locks you out:

```sh
sudo systemd-run --unit=oob-fw-revert --on-active=90 /usr/sbin/nft delete table inet oob
sudo nft -f /etc/nftables.d/oob.nft
# open a NEW session to prove it still works, then:
sudo systemctl stop oob-fw-revert.timer
```

---

## Things that will bite you

**Power the phone from a wall charger, never from moose.** Powered from the
machine it exists to rescue, the out-of-band path dies exactly when needed. The
battery doubles as a UPS. A flat battery also caused a failed eMMC flash: the
phone browned out mid-write on a 500 mA hub port.

**Hardware kill switches:** WiFi on, cellular off, camera/mic off.

**Never `poweroff`.** There is no reliable way to power the phone back on
remotely. Use `reboot`. The hardware watchdog (30 s) recovers hangs but not a
clean shutdown.

**The BMC resets its configuration on every power loss**, so it may revert to
factory credentials. Nothing here depends on a BMC-side setting — it gets its
address by DHCP — but treat the tailnet ACL as the only access control.

**Kernel and bootloader are excluded from unattended-upgrades** on purpose.
There is no serial console; an unattended kernel bump that fails to boot is
unrecoverable without physically handling the phone. Update those by hand, with
the phone in front of you.

**No package owns any file installed here**, so upgrades will not remove them
(verified with `dpkg -S`).

---

## Tailnet policy

`tailnet/tailnet-policy-corrected.hujson` is the live policy.
`tailnet/tailnet-apply.sh` applies it and retags machines via the API.

Access model:

| Identity | Reach |
|---|---|
| human users | everything, BMC included |
| `tag:workstation` (moose, Tolken) | everything, BMC included |
| `tag:app` (immich, nextcloud, overleaf, leaf, fbi-surveillance-gateway) | reachable; initiates nothing |
| `tag:wk` (rpi4, rpi5, dev containers) | other `tag:wk` nodes only |
| `tag:oob` (this phone) | initiates nothing; it only routes |

Tailscale ACLs are allow-only, so "cannot initiate" is expressed by granting
no `src` rule at all. `10.99.0.0/24` is reachable only by humans and
`tag:workstation`.

Never add a rule letting `tag:app` or `tag:wk` SSH to `tag:oob` — root on this
router is equivalent to BMC access, which would defeat the whole model.
