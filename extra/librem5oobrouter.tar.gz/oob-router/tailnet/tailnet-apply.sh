#!/bin/bash
# Apply the tailnet reorganisation via the Tailscale API, in the order that
# avoids an outage:
#
#   Phase 1  add tag:workstation and tag:app to tagOwners ONLY, so they become
#            assignable. Behaviour is unchanged because the existing allow-all
#            rule still covers every tag.
#   Phase 2  retag the machines. Still no behaviour change.
#   Phase 3  install the real policy. This is where restrictions take effect.
#
# Doing Phase 3 first would cut off every tag:server node at once, moose
# included.
#
# Usage:  TS_API_KEY=tskey-api-... ./tailnet-apply.sh [--dry-run]

set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
TAILNET="${TAILNET:-tail4236a7.ts.net}"
FINAL_POLICY="${HERE}/config/tailnet-policy-corrected.hujson"
BACKUP_DIR="${HERE}/tailnet-backups"
API="https://api.tailscale.com/api/v2"
DRY_RUN="no"
[ "${1:-}" = "--dry-run" ] && DRY_RUN="yes"

step() { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
info() { printf '    %s\n' "$*"; }
warn() { printf '\033[1;33m    WARN: %s\033[0m\n' "$*"; }
die()  { printf '\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

[ -n "${TS_API_KEY:-}" ] || die "set TS_API_KEY"
[ -f "$FINAL_POLICY" ]   || die "missing $FINAL_POLICY"

api() {  # api <method> <path> [datafile] [content-type]
    local m="$1" p="$2" f="${3:-}" ct="${4:-application/json}"
    if [ -n "$f" ]; then
        curl -sS -X "$m" -u "${TS_API_KEY}:" -H "Content-Type: ${ct}" \
             --data-binary "@${f}" "${API}${p}"
    else
        curl -sS -X "$m" -u "${TS_API_KEY}:" "${API}${p}"
    fi
}

# device-id  ->  desired tag
RETAG="
nQ1XjsAkvF11CNTRL moose                    tag:workstation
nGpzGBnrde11CNTRL Tolken                   tag:workstation
nwSPo75Mu121CNTRL immich                   tag:app
nJxJe8gJVo11CNTRL nextcloud                tag:app
nHXSuAdpm321CNTRL overleaf                 tag:app
nNVEJiEnya11CNTRL leaf                     tag:app
nbvrfoMBBn11CNTRL fbi-surveillance-gateway tag:app
nZzTwHHQgV11CNTRL rpi5                     tag:wk
"

mkdir -p "$BACKUP_DIR"

# ----------------------------------------------------------------- preflight ---
step "Checking the token"
raw="$(api GET "/tailnet/${TAILNET}/acl")"
grep -q '"message"' <<<"$raw" && grep -qi 'invalid\|unauthor' <<<"$raw" \
    && die "token rejected: $raw"
ts="$(date -u +%Y%m%dT%H%M%SZ)"
printf '%s' "$raw" > "${BACKUP_DIR}/acl-${ts}.hujson"
info "token OK; current policy backed up to tailnet-backups/acl-${ts}.hujson"
info "$(wc -l < "${BACKUP_DIR}/acl-${ts}.hujson") lines"

# ------------------------------------------------------------------- phase 1 ---
step "Phase 1: making tag:workstation and tag:app assignable"
# Minimal textual edit to the live policy: insert two entries at the top of the
# tagOwners block. Deliberately not a wholesale rewrite, so the live policy's
# comments and any drift are preserved at this stage.
python3 - "$raw" > "${BACKUP_DIR}/phase1-${ts}.hujson" <<'PY'
import re, sys
doc = sys.argv[1]
add = '\n\t\t"tag:workstation": ["autogroup:admin"],\n\t\t"tag:app":         ["autogroup:admin"],'
if '"tag:workstation"' in doc and '"tag:app"' in doc:
    sys.stderr.write("    already present, no edit needed\n")
    sys.stdout.write(doc); sys.exit(0)
# The stock policy ships a COMMENTED-OUT tagOwners example near the top:
#     // "tagOwners": {
# Matching that one would splice live JSON into a comment block. Only accept a
# match whose own line is not commented out.
target = None
for m in re.finditer(r'"tagOwners"\s*:\s*\{', doc):
    line_start = doc.rfind('\n', 0, m.start()) + 1
    if not doc[line_start:m.start()].lstrip().startswith('//'):
        target = m
        break
if target is None:
    sys.stderr.write("ERROR: no live tagOwners block found\n"); sys.exit(1)
i = target.end()
sys.stdout.write(doc[:i] + add + doc[i:])
PY

step "Validating the Phase 1 policy before sending it"
v="$(api POST "/tailnet/${TAILNET}/acl/validate" "${BACKUP_DIR}/phase1-${ts}.hujson" "application/hujson")"
[ -z "$v" ] || [ "$v" = "{}" ] || { echo "$v"; die "Phase 1 policy rejected"; }
info "valid"

if [ "$DRY_RUN" = "yes" ]; then warn "dry run: stopping before any write"; exit 0; fi

api POST "/tailnet/${TAILNET}/acl" "${BACKUP_DIR}/phase1-${ts}.hujson" "application/hujson" >/dev/null
info "tagOwners updated"

# ------------------------------------------------------------------- phase 2 ---
step "Phase 2: retagging machines"
printf '%s\n' "$RETAG" | while read -r id name tag; do
    [ -n "${id:-}" ] || continue
    body="$(mktemp)"; printf '{"tags":["%s"]}' "$tag" > "$body"
    out="$(api POST "/device/${id}/tags" "$body")"
    rm -f "$body"
    # The tags endpoint returns a bare JSON null on success, not an empty body.
    if [ -z "$out" ] || [ "$out" = "{}" ] || [ "$out" = "null" ]; then
        printf '    %-26s -> %s\n' "$name" "$tag"
    else
        printf '\033[1;31m    %-26s -> %s FAILED: %s\033[0m\n' "$name" "$tag" "$out"
    fi
done

# ------------------------------------------------------------------- phase 3 ---
step "Phase 3: validating the final policy"
v="$(api POST "/tailnet/${TAILNET}/acl/validate" "$FINAL_POLICY" "application/hujson")"
[ -z "$v" ] || [ "$v" = "{}" ] || { echo "$v"; die "final policy rejected — tags are applied but the old policy is still live"; }
info "valid (its tests passed)"

api POST "/tailnet/${TAILNET}/acl" "$FINAL_POLICY" "application/hujson" >/dev/null
step "Final policy applied"

# -------------------------------------------------------------------- verify ---
step "Verifying"
api GET "/tailnet/${TAILNET}/devices" \
    | jq -r '.devices[] | "    \(.name|split(".")[0])\t\(.tags // ["user-owned"] | join(","))"' \
    | sort
echo
info "no node should still show tag:server"
