# Build log — Librem 5 out-of-band router

Built 2026-08-17/18. This records *what* was done and, more usefully, *why* —
including the dead ends, because several of them are traps that will be walked
into again otherwise.

For operating instructions see `README.md`. This file is history and rationale.

---

## 1. The goal

Put moose's BMC on the tailnet so the machine is reachable when it is powered
off, hung, or its OS is broken. A spare Librem 5 was the available hardware.

```
house WiFi ──wlan0── [ Librem 5 ] ──bmc0── moose's dedicated BMC port
                          │
                 tailscaled (tag:oob)
                 advertises 10.99.0.0/24
```

The design decision that shaped everything else: **the BMC's configuration
resets on every power loss**, so nothing may depend on a BMC-side setting. It
gets its address by DHCP from the phone, and Tailscale's default subnet-router
SNAT means it never needs a route back to the tailnet. Its credentials may
revert to factory defaults at any time, so the tailnet ACL is the real access
control, not the BMC's own auth.

---

## 2. Distro: started on Mobian, ended on PureOS

**Chosen first: Mobian 13 (trixie).** Reasoning was sound on paper — Debian 13
base, current security stream, Librem 5 is a first-tier device there.

**Switched to PureOS 11 (Crimson).** Not for ideological reasons; the Mobian
image was ten months old (13.0, October 2025) and Debian point releases had
superseded and removed the binaries its apt index referenced. `apt install
openssh-server` failed fetching `libwtmpdb0` at a version no longer in the
pool. Combined with no usable input device on the phone, that was unrecoverable
without reflashing anyway.

PureOS Crimson turned out better on the merits:

| | Mobian 13.0 | PureOS 11 Crimson |
|---|---|---|
| Image age | 10 months | 3 months (20260515) |
| Kernel | 6.6 | **6.12** |
| Base | Debian 13 trixie | Debian 12 bookworm |
| `apt update` on device | index stale, 404s | works |

Purism writes the Librem 5 kernel patches and QAs against PureOS. Mobian keeping
the L5 on 6.6 while its other devices moved to 6.12 was the tell.

**Take the `plain` variant, never `luks`.** `librem5-flash-image` defaults to
`luks`, which demands a passphrase at every boot — fatal for a headless router.

---

## 3. What went wrong, and why

### The first flash browned out

Died 55 s into the 5.6 G rootfs write with `LIBUSB_ERROR_NO_DEVICE`. Kernel log
showed the link degrading first — `device descriptor read/64, error -32`, then a
**12 Mbit/s full-speed** enumeration where high-speed was expected.

Cause: a ~500 mA USB-2 hub port plus a depleted battery. Every external USB port
on a Thelio Astra sits behind an ASM1074 hub; there is no directly accessible
root port. During flashing the battery supplies the current spikes and USB only
tops it up, so a flat battery collapses.

Fix: charge fully first. `host-flash.sh` now refuses to start the write unless
the link enumerated at 480 Mbit/s, and dumps annotated USB events on failure.

**This is a preview of the steady-state risk.** A phone that browns out at
500 mA is not a dependable always-on router fed from the machine it exists to
rescue. Power it from a wall charger.

### No way to type on the phone

The USB keyboard would not enumerate, and the on-screen keyboard was unusable.
That invalidated every "run this on the phone" instruction.

The Librem 5 has one USB-C port that defaults to *device* mode. It only becomes
a *host* if the attached hub requests it on the CC pins. A powered hub makes the
phone a power **sink**, and the data role follows unless the dock performs a
**Data Role Swap**.

In the end the dock did do the swap — `data_role` reads `[host] device` and the
AX88179 enumerates — so the keyboard failure was something else. But the risk is
real and permanent, which is why `oob-usb-host.service` forces host mode at boot
and the watchdog re-asserts it whenever `bmc0` disappears.

### The Ethernet cable was in the wrong socket

dnsmasq issued its one address to a client identifying as `moose`. The cable was
in moose's onboard NIC, not the BMC's dedicated port.

Worse, the design made it permanent: a **single-address pool with an infinite
lease** is captured by whatever asks first, forever. When the cable moved, the
BMC was refused with `no address available`.

Fix: a MAC reservation (`dhcp-host=9c:6b:00:75:5a:d7,10.99.0.2,infinite`), plus
logic to clear a stale lease held by another MAC. The BMC's MAC survives its
config resets, so it is a safe key.

### dnsmasq fought systemd-resolved for port 53

`port=0` disables DNS, but Debian's unit runs everything through
`/usr/share/dnsmasq/systemd-helper`, which sources `/etc/default/dnsmasq` for the
conf-dir and also wires up resolvconf. Our setting never reached the daemon, so
it tried to bind `0.0.0.0:53` and collided.

Fix: a drop-in that clears every `Exec*` and invokes
`dnsmasq -k --conf-file=/etc/dnsmasq.d/oob-bmc.conf` directly, so neither
`/etc/dnsmasq.conf` nor the conf-dir is read.

### The Tailscale node joined untagged

The first auth key carried no tag. Consequences: `KeyExpiry: 2027-02-14` — the
OOB path would have died silently after 180 days — and `autoApprovers` could not
match, so `PrimaryRoutes` stayed `null` and the BMC was unroutable.

Fix: re-auth with a `tag:oob` key. Tagged nodes never key-expire, and the route
auto-approved with no console click.

### A `grep -q` bug that reported success as failure

The health check claimed SSH password auth was enabled when it was not.

`cmd | grep -q ...` exits at the first match, SIGPIPEs the producer, and under
`set -o pipefail` the pipeline returns non-zero. Three occurrences fixed.
**Do not reintroduce this pattern.** Capture the value and compare it.

### Two units that fail forever

`zramswap.service` (zram-tools) cannot claim `/dev/zram0` because PureOS uses
`systemd-zram-generator`. `console-setup.service` fails every boot on PureOS
with `setupcon: cannot open /tmp/tmpkbd.XXXX`.

Both masked. Neither matters functionally, but a permanently `degraded` system
state would hide a real fault.

### Things that looked like faults and were not

* **SSH sessions dropping while the phone stayed up.** The house has two APs on
  one SSID; the phone roams between them and a roam stalls TCP long enough to
  kill an idle session. Uptime was unbroken and the watchdog logged nothing. Use
  `ServerAliveInterval`.
* **`/root/.ssh/authorized_keys` vanishing.** Deliberately deleted to test
  Tailscale SSH. No package, reboot or journal event was behind it — worth
  chasing precisely because updates provably do not do this.

---

## 4. Final configuration

| Area | What |
|---|---|
| BMC segment | `bmc0` = `10.99.0.1/24`, pinned by MAC via systemd `.link` |
| DHCP | dnsmasq, DNS off, one-address pool + MAC reservation → `10.99.0.2` |
| NTP | chrony serves the BMC, whose clock also resets; `makestep` for large offsets |
| Firewall | `table inet oob`, separate from Tailscale's chains. Input default-deny; forward `tailscale0 → bmc0` only |
| USB | `oob-usb-host.service` forces Type-C host mode at boot |
| Watchdogs | hardware watchdog 30 s; `oob-netwatch` every 60 s with escalating recovery |
| Throughput | `rx-udp-gro-forwarding on` via NetworkManager dispatcher hook |
| SSH | key-only; password auth disabled. Default password kept for console login |
| Storage | zram-only swap, journald capped at 64 M, `noatime` |
| Updates | security-only; kernel, firmware and u-boot blacklisted |

**Deliberate:** the GUI is left enabled (`HEADLESS=no`). The phone's screen is
the only fallback if WiFi and SSH both fail. Masking phosh removes it.

Debian's `nftables.service` is disabled because its stock config does
`flush ruleset`, which would destroy Tailscale's `ts-input`/`ts-forward` chains.

No file installed here is owned by any package (verified with `dpkg -S`), so
upgrades cannot remove them.

---

## 5. Tailnet model

| Identity | Reach |
|---|---|
| humans | everything, BMC included |
| `tag:workstation` (moose, Tolken) | everything, BMC included |
| `tag:app` (immich, nextcloud, overleaf, leaf, fbi-surveillance-gateway) | reachable; initiates nothing |
| `tag:wk` (rpi4, rpi5, dev containers) | other `tag:wk` nodes only |
| `tag:oob` (this phone) | initiates nothing; it only routes |

ACLs are allow-only, so "cannot initiate" is expressed by granting no `src` rule.
`tag:server` was retired — moose, rpi5 and the app servers all shared it, and
ACLs cannot distinguish nodes with the same tag.

Applied in three phases to avoid an outage: make tags assignable, retag the
machines, then install the restrictive policy. Doing it in the other order would
have cut off every `tag:server` node at once, moose included.

There is deliberately **no** `tag:app`/`tag:wk` → `tag:oob` SSH rule. Root on
this router is equivalent to BMC access.

---

## 6. Known risks

**The RS9116 WiFi is the weakest component.** Expect occasional drops; the
watchdog escalates through link bounce, NetworkManager restart, driver reload,
tailscaled restart, and finally a rate-limited reboot.

**Single point of failure.** The out-of-band path depends on this phone, its
battery, its dock and the house WiFi. If the ISP or AP is down, so is access —
a cellular SIM would be the fix, and was declined.

**Never `poweroff`.** There is no reliable remote power-on. The watchdog
recovers hangs, not clean shutdowns.

**This directory is the only copy.** moose was wiped. Push it to git.
